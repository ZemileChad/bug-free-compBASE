/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Foot;

/**
 *
 * @author User
 */
public class Ellipse extends Foot {
    @Override
    public String draw() {
        return "draw ellipse";
    }
}
